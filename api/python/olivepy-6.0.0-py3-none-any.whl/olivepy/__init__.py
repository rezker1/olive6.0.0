"""
olivePy: Implementation of the Olive Enterprise API in Python

"""

# from olivepy.api.oliveclient import OliveClient
# from olivepy.messaging.msgutil import ExceptionFromServer

__version__  = '6.0.0'
