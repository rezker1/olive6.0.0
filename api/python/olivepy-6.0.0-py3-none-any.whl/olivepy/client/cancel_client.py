

import argparse
import os, time
import logging

from olivepy.api.olive_async_client import AsyncOliveClient


if __name__ == '__main__':
    parser = argparse.ArgumentParser(prog='olivepycancel')
    
    parser.add_argument('-P', '--port', type=int, action='store', default=5588,
                        help='The port to use.')
    parser.add_argument('-s', '--server', action='store', default='localhost',
                        help='The machine the server is running on. Defaults to %(default)s.')
    parser.add_argument('-t', '--timeout', type=int, action='store', default=10,
                        help='The timeout to use')

    args_bad = False
    args = parser.parse_args()

    start = time.time()

    logging.basicConfig(level=logging.DEBUG)
    
    client = AsyncOliveClient('olivepycancel', args.server, args.port, args.timeout)
    client.connect()

    file_mode = 'w'
    try:
        client.cancel_server_jobs(server_wide=True)
    finally:
        client.disconnect()

    print('Server-wide jobs cancellation requested')
