
import argparse
import logging
import time
import os
from pathlib import Path
import uuid
import json

import olivepy.client.client_common as client_com
from olivepy.messaging import olive_pb2
from olivepy.messaging.msgutil import OliveInputDataType
from olivepy.messaging.msgutil import AudioTransferType, InputTransferType
from olivepy.messaging.msgutil import  BOUNDING_BOX_SCORER
from olivepy.messaging.msgutil import serialize_message

from olivepy.api.olive_async_client import AsyncOliveClient

# Todo:
#   * Should we accept both enroll and unenroll in the same command line.


# This is the main function of the script.  It does two things:
#   1. Gather up the command line arguments.
#   2. Connect to the server, do the enrollment, and disconnect from the server.

if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(prog='olivepyenroll')
    
    parser.add_argument('-C', '--client-id', action='store', default='oliveenroll',
                        help='Experimental: the client_id to use')

    parser.add_argument('-D', '--debug', action='store_true',
                        help='The domain to use')

    parser.add_argument('-p', '--plugin', action='store',
                        help='The plugin to use.')
    parser.add_argument('-d', '--domain', action='store',
                        help='The domain to use')

    parser.add_argument('-e', '--enroll', action='store',
                        help='Enroll with this name.')
    parser.add_argument('-u', '--unenroll', action='store',
                        help='Uneroll with this name.')
    
    parser.add_argument('-v', '--vectorize', action='store_true',
                        help='Vectorize for stateless scoring.')

    parser.add_argument('-s', '--server', action='store', default='localhost',
                        help='The machine the server is running on. Defaults to %(default)s.')
    parser.add_argument('-P', '--port', type=int, action='store', default=5588,
                        help='The port to use.')
    parser.add_argument('--upload_port', type=int, action='store', default=5000,
                        help='The upload port to use when specifying --upload_files.')

    parser.add_argument('-t', '--timeout', type=int, action='store', default=30,
                        help='The timeout to use')

    # parser.add_argument('-a', '--audio', action='store',
    #                     help='The audio file to enroll. Required for --enroll command.')
    parser.add_argument('-i', '--input', action='store',
                        help='The data input to analyze.  Either a pathname to an audio/image/video file or a string for text input.  For text input, also specify the --text flag')
    parser.add_argument('--input_list', action='store',
                        help='A list of files to analyze. One file per line.')
    parser.add_argument('--nobatch', type=bool, action='store', default=False,
                        help='Disable batch enrollment when using pem or list input files, so that files are processed individually.')
    parser.add_argument('--path', action='store_true',
                        help='Send the path of the audio instead of a buffer.  '
                             'Server and client must share a filesystem to use this option')
    parser.add_argument('--upload_files', action='store_true',
                        help='Must be specified with --path argument. This uploads the files to the server so the client and server do not need to share a filesystem. This can also be used to bypass the 2 GB request size limitation.')

    parser.add_argument('--secure', action='store_true', 
                        help='Indicates a secure connection should be made.  Requires --certpath, --keypass, --keypath, and --cabundlepath to be set.')
    parser.add_argument('--certpath', action='store', 
                        help='Specifies the path of the certificate')
    parser.add_argument('--keypath', action='store', 
                        help='Specifies the path of the certificate key')
    parser.add_argument('--keypass', action='store', 
                        help='Specifies the certificate passphrase to unlock the encrypted certificate key')    
    parser.add_argument('--cabundlepath', action='store', 
                        help='Specifies the path of the certificate authority')
    
    args_bad = False
    args = parser.parse_args()
    
    # Get into debug mode as soon as possible.
    if args.debug:
        logging.basicConfig(level=logging.DEBUG, force=True)
    
    if args.plugin is None or args.domain is None:
        print('No plugin or domain is specified and one of each is required.')
        args_bad = True

    if args.upload_files and not args.path:
        print('--upload_files must be combined with --path')
        args_bad = True

    if (args.enroll is None and args.input_list is None) and args.unenroll is None:
        print('No command has been given.  Either enroll or unenroll must be given or nothing will be done.')
        args_bad = True

    require_data = False
    if args.enroll is not None:
        require_data = True
        
    if args.unenroll is not None and args.input is not None:
        print('Warning: The unenroll command does not use a input file, so that argument will be ignored.')

    if args.path:
        # validate paths in our list?
        # print('Sending audio as a path name')
        audio_mode = AudioTransferType.AUDIO_PATH
        print("send as path")
    else:
        # print('Sending audio as a serialized buffer')
        audio_mode = AudioTransferType.AUDIO_SERIALIZED

    if args.client_id is None or args.server is None or args.port is None or args.timeout is None:
        print('Internal error: a required variable is not set.')
        quit(2)

    # checking for if tls is enabled and correctly set up
    secure_connect = False
    if args.secure:
        if (args.certpath is None or args.keypass is None or args.cabundlepath is None or args.keypath is None):
            args_bad = True
            print('--secure requires --certpath, --keypass, --keypath, and --cabundlepath')
        else:
            secure_connect = True

    if args_bad:
        print('Run the command with --help or -h to see all the command line options.')
        quit(1)

    # client = olivepy.api.oliveclient.OliveClient(args.client_id, args.server, args.port, args.timeout)
    # client.connect()
    client = AsyncOliveClient(args.client_id, args.server, args.port, args.timeout)
    
    if not secure_connect:
        client.connect()
    else:
        client.secure_connect(certfile=args.certpath, keyfile=args.keypath, password=args.keypass, ca_bundle_path=args.cabundlepath)

    expected_data_type = OliveInputDataType.AUDIO_DATA_TYPE

    # plug, domain = client.request_plugins(args.plugin, args.domain)
    plugin_dir_req = client.request_plugins()
    response = plugin_dir_req.get_response()
    # send as audio data, unless plugin is a bounding box scorer then send as binary media
    for plugin in response.plugins:
        for domain in plugin.domain:
            if args.plugin == plugin.id and args.domain == domain.id:
                for trait in plugin.trait:
                    if BOUNDING_BOX_SCORER  == trait.type:
                        expected_data_type = OliveInputDataType.BINARY_DATA_TYPE
                        break

    # if args.text:
    #     # special case of handling text data
    #     expected_data_type = OliveInputDataType.TEXT_DATA_TYPE
    # elif args.box:
    #     expected_data_type = OliveInputDataType.BINARY_DATA_TYPE
    # else:
    #     expected_data_type = OliveInputDataType.AUDIO_DATA_TYPE
    
    start = time.time()

    data_input, transfer_mode, send_pathname = client_com.extract_input_data(args, expected_data_type=expected_data_type, fail_if_no_data=require_data, has_class_ids=True)    

    try:
        if args.vectorize:
            for class_id in data_input.keys():
                class_id_path = Path(args.plugin, args.domain, 'enrollments', class_id)
                response = client.vectorize_audio(args.plugin, args.domain, data_input[class_id], callback=None, mode=InputTransferType.SERIALIZED)
                os.makedirs(class_id_path, exist_ok=True)
                i = 0
                for vector_result in response.get_response().vector_result:
                    if not vector_result.successful:
                        print(vector_result.message + " for audio at index " + str(i) + "class " + class_id)
                    else:
                        vector_filename = str(uuid.uuid4())
                        for p in vector_result.audio_vector.params:
                            if p.name == 'id':
                                vector_id = olive_pb2.StringMetadata()
                                vector_id.ParseFromString(p.value)
                                vector_filename = vector_id.value
                                break
                        with open(class_id_path / Path(vector_filename), 'wb') as f:
                            f.write(serialize_message(vector_result.audio_vector))
                    i += 1

        elif args.enroll is not None or args.input_list is not None:
            if args.nobatch:
                for class_id in data_input.keys():
                    for input in data_input[class_id]:
                        response = client.enroll(args.plugin, args.domain, class_id, input, callback=None, mode=InputTransferType.SERIALIZED)
                        if response.is_successful():
                            success_count = 0
                            for res in response.get_response().addition_result:
                                if res.successful:
                                    success_count += 1
                            for res in response.get_response().binary_addition_result:
                                if res.successful:
                                    success_count += 1
                            print('Successfully enrolled {} in {} {}'.format(class_id, args.plugin, args.domain))
                        else:
                            print('Failed to enroll {} in {} {}'.format(class_id, args.plugin, args.domain))
            else:
                class_ids = data_input.keys()
                class_id_inputs = {}
                for class_id in data_input.keys():
                    inputs = []
                    for input in data_input[class_id]:
                        inputs.append(input)
                    if len(inputs) == 0:
                        continue
                    class_id_inputs[class_id] = inputs
                class_count = len(class_id_inputs.keys())
                classes_processed = 0
                for class_id in class_id_inputs.keys():
                    inputs = class_id_inputs[class_id]
                    response = client.enroll(args.plugin, args.domain, class_id, inputs, callback=None, mode=InputTransferType.SERIALIZED)
                    if response.is_successful():
                        success_count = 0
                        for res in response.get_response().addition_result:
                            if res.successful:
                                success_count += 1
                        for res in response.get_response().binary_addition_result:
                            if res.successful:
                                success_count += 1
                        print('Successfully batch enrolled {} in {} {}, successful enrollments: {}'.format(class_id, args.plugin, args.domain, success_count))
                    else:
                        print('Failed to batch enroll {} in {} {}'.format(class_id, args.plugin, args.domain))
                    classes_processed += 1

        if args.unenroll is not None:
            response = client.unenroll(args.plugin, args.domain, args.unenroll)
            if response.is_successful():
                print('Successfully unenrolled {} from {} {}'.format(args.unenroll, args.plugin, args.domain))
            else:
                # error message wasn't added to ClassRemovalResult until after 5.6.0.. so it may or may not be available
                if response.get_error():
                    print('Failed to unenroll {} from {} {} because: {}'.format(args.unenroll, args.plugin, args.domain, response.get_error()))
                else:
                    print('Failed to unenroll {} from {} {}'.format(args.unenroll, args.plugin, args.domain))
    except Exception as e:
        print("Enrollment failed with error: {}".format(e))
    finally:
        client.disconnect()
    
    end = time.time()
    print(f'took {end - start} s')
