

import argparse
import time
import asyncio

from olivepy.api.olive_async_client import AsyncOliveClient
from olivepy.messaging.msgutil import InputTransferType, package_audio, serialize_audio
from olivepy.messaging.olive_pb2 import Audio


def heartbeat_notification(heartbeat):
    if heartbeat.HasField("stats"):
        stats = heartbeat.stats
        print("System CPU Used:    %02.01f%%" % stats.cpu_percent)
        print("System CPU Average: %02.01f%%" % stats.cpu_average)
        print("System MEM Used:    %02.01f%%" % stats.mem_percent)
        print("System MEM Max:     %02.01f%%" % stats.max_mem_percent)
        print("System SWAP Used:   %02.01f%%" % stats.swap_percent)
        print("System SWAP Max:    %02.01f%%" % stats.max_swap_percent)
        print("Number active jobs: " + str(stats.pool_busy))
        print("Number pending jobs: " + str(stats.pool_pending))
        print("Number finished jobs: " + str(stats.pool_finished))
        print("Max number jobs: " + str(stats.max_num_jobs))
        print("Server version: " + str(stats.server_version))
        print("Server version: " + str(stats.server_version))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(prog='quickstart_secure')

    parser.add_argument('-P', '--port', type=int, action='store', default=5588,
                        help='The port to use.') 
    parser.add_argument('-s', '--server', action='store', default='localhost',
                        help='The machine the server is running on. Defaults to %(default)s.')
    parser.add_argument('-t', '--timeout', type=int, action='store', default=30,
                        help='The timeout to use')  
    parser.add_argument('-i', '--input', action='store',
                        help='The data input to analyze.  Either a pathname to an audio/image/video file or a string for text input.')
    
    args = parser.parse_args()

    iterations = 15
    
    client = AsyncOliveClient("quickstart_secure.py", args.server, args.port, args.timeout)
    client.add_heartbeat_listener(heartbeat_callback=heartbeat_notification)
    try:
        client.secure_connect(certfile="/etc/nginx/certs/server.crt", keyfile="/etc/nginx/certs/server.key", password="olive", ca_bundle_path="/etc/nginx/certs/clientCA.crt")
    except asyncio.exceptions.TimeoutError:
        print("timeout connecting to OLIVE")
        exit(-1)
    
    plugin_dir_req = client.request_plugins()
    response = plugin_dir_req.get_response()
    for plugin in response.plugins:
        print(f'Plugin {plugin.id} ({plugin.task},{plugin.group}) {plugin.version} has {len(plugin.domain)} domain(s):')
        for domain in plugin.domain:
            print(f'\tDomain: {domain.id}, Description: {domain.desc}')
    for plugin in response.plugins:
        if plugin.task == 'LID':
            selected_plugin = plugin
    
    packaged_audio = package_audio(Audio(), serialize_audio(args.input), mode=InputTransferType.SERIALIZED)
    success_count = 0
    error_count = 0
    analyze_response = None
    def result_callback(response):
        global success_count
        global error_count
        global analyze_response
        if response.is_successful():
            success_count += 1
            print(f"success_count: {success_count}")
            analyze_response = response.get_response()
        if response.is_error():
            error_count += 1
    for i in range(iterations):
        print(f"sending request {i+1}")
        analyze_request = client.analyze_global(selected_plugin.id, selected_plugin.domain[0].id, packaged_audio, callback=result_callback)
        # analyze_response = analyze_request.get_response()

    while success_count < iterations:
        time.sleep(0.1)
    top_scoring = analyze_response.score[0]
    for score in analyze_response.score:
        print(f"{score.class_id}={score.score}")
        if score.score > top_scoring.score:
            top_scoring = score

    print(f"\nTop scoring: {top_scoring.class_id} ({top_scoring.score})")

    # time.sleep(60)

    client.disconnect()
