import threading
import argparse, json, time

import olivepy.client.client_common as client_com
from olivepy.messaging.msgutil import InputTransferType, OliveInputDataType
from olivepy.api.olive_async_client import AsyncOliveClient


class MtResult(object):
    def __init__(self, path, func, plugin, domain):
        self.path = path
        self.translation = ''
        self.success = False
        self.error = None
        self.func = func
        self.plugin = plugin
        self.domain = domain
        self.result_available = threading.Event()

    def __call__(self, response):
        if response.is_successful():
            for transformation in response.get_response().transformation:
                self.translation += transformation.transformed_text
            self.success = True
            self.result_available.set()
        else:
            self.error = response.get_error()
            self.result_available.set()


class AsrResult(object):
    def __init__(self, path, next):
        self.path = path
        self.asr_text = ''
        self.success = False
        self.error = None
        self.next = next
    
    def __call__(self, response):
        if response.is_successful():
            for region in response.get_response().region:
                self.asr_text += region.class_id + ' '
            self.success = True
            self.next.func(self.next.plugin, self.next.domain, self.asr_text, self.next)
        else:
            self.error = response.get_error()
            self.next.result_available.set()


if __name__ == '__main__':

    parser = argparse.ArgumentParser(prog='search_asr_mt', description="Perform a search over ASR and MT results for words or phrases")
    parser.add_argument('-i', '--input', action='store', required=False, help='A pathname to an audio file')
    parser.add_argument('--input_list', action='store', required=False, help='A pathname to a text file containing audio file paths')
    parser.add_argument('-s', '--search_input', action='store', required=True, help='Either a pathname to a file with search words or phrases')
    parser.add_argument('--asr_plugin', action='store', required=True, help='ASR plugin')
    parser.add_argument('--asr_domain', action='store', required=True, help='ASR domain')
    parser.add_argument('--mt_plugin', action='store', required=True, help='MT plugin')
    parser.add_argument('--mt_domain', action='store', required=True, help='MT domain')
    parser.add_argument('--plain', action='store_true', required=False, default=False, help='Output plaintext results')

    args = parser.parse_args()

    args_bad = False
    if args.input_list and args.input:
        args_bad = True
    elif args.input_list == None and args.input == None:
        args_bad = True
    
    if args_bad:
        print('Run the command with --help or -h to see all the command line options.')
        quit(1)
    
    if args.input:
        input_paths = [args.input]
    else:
        with open(args.input_list) as input_list:
            input_paths = input_list.readlines()
    
    with open(args.search_input) as search_file:
        search_terms = search_file.readlines()
        # reverse order allows longer phrases to be first, allowing better highlighting
        search_terms.sort(reverse=True)
    
    client = AsyncOliveClient("search_client", timeout_second=500)
    client.connect()
    
    asr_callbacks = {}
    mt_callbacks = {}
    for input_path in input_paths:
        input_path = input_path.strip()
        input_data = client_com.convert_filename_to_data(input_path, InputTransferType.SERIALIZED, OliveInputDataType.AUDIO_DATA_TYPE)
        mt = MtResult(input_path, client.analyze_text, args.mt_plugin, args.mt_domain)
        asr_cb = AsrResult(input_path, mt)
        asr_callbacks[input_path] = asr_cb
        mt_callbacks[input_path] = mt
        client.analyze_regions(args.asr_plugin, args.asr_domain, input_data, asr_cb)

    analysis = {}
    for input_path in mt_callbacks.keys():
        analysis[input_path] = {}
        mt_callbacks[input_path].result_available.wait()
        if asr_callbacks[input_path].success:
            asr_text = asr_callbacks[input_path].asr_text
            analysis[input_path]['asr'] = { 'text': asr_text, 'matches': {} }
            highlighted = asr_text.lower()
            for term in search_terms:
                term = term.strip()
                if term.lower() in asr_text.lower():
                    analysis[input_path]['asr']['matches'][term] = asr_text.lower().count(term.lower())
                    highlighted = highlighted.replace(term.lower(), f'[{term.lower()}]')
            if highlighted != asr_text.lower():
                analysis[input_path]['asr']['highlighted'] = highlighted
        if mt_callbacks[input_path].success:
            translation = mt_callbacks[input_path].translation
            analysis[input_path]['translation'] ={ 'text': translation, 'matches': {} }
            highlighted = translation.lower()
            for term in search_terms:
                term = term.strip()
                if term.lower() in translation.lower():
                    analysis[input_path]['translation']['matches'][term] = translation.lower().count(term.lower())
                    highlighted = highlighted.replace(term.lower(), f'[{term.lower()}]')
            if highlighted != translation.lower():
                analysis[input_path]['translation']['highlighted'] = highlighted

    if args.plain:
        for input in analysis.keys():
            print(input)

            print(f"asr text: {analysis[input]['asr']['text']}")
            for match in analysis[input]['asr']['matches'].keys():
                match_count = analysis[input]['asr']['matches'][match]
                print(f'match: {match} ({match_count})')
            if 'highlighted' in analysis[input]['asr']:
                print(analysis[input]['asr']['highlighted'])

            print(f"translated text: {analysis[input]['translation']['text']}")
            for match in analysis[input]['translation']['matches']:
                match_count = analysis[input]['translation']['matches'][match]
                print(f'match: {match} ({match_count})')
            if 'highlighted' in analysis[input]['translation']:
                print(analysis[input]['translation']['highlighted'])
            
            print('\n')
    else:
        print(json.dumps(analysis, ensure_ascii=False, indent=2))
