

import argparse
import os, time
import json
import logging
import signal
import traceback

import olivepy.api.olive_async_client as olive_async


def heartbeat_notification(heatbeat):
    """Callback method, notified by the async client that a heartbeat message has been received from the OLIVE server"""

    if heatbeat:
        if heatbeat.HasField("stats"):
            stats = heatbeat.stats
            print("System CPU Used:    %02.01f%%" % stats.cpu_percent)
            print("System CPU Average: %02.01f%%" % stats.cpu_average)
            print("System MEM Used:    %02.01f%%" % stats.mem_percent)
            print("System MEM Max:     %02.01f%%" % stats.max_mem_percent)
            print("System SWAP Used:   %02.01f%%" % stats.swap_percent)
            print("System SWAP Max:    %02.01f%%" % stats.max_swap_percent)
            print("Number active jobs: " + str(stats.pool_busy))
            print("Number pending jobs: " + str(stats.pool_pending))
            print("Number finished jobs: " + str(stats.pool_finished))
            print("Max number jobs: " + str(stats.max_num_jobs))
            print("Server version: " + str(stats.server_version))
            print("\n")
    else:
        print("No OLIVE heartbeat received.  Olive server or connection down")


if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(prog='olivepystatus')
    
    parser.add_argument('-C', '--client-id', action='store', default='olivepy_status',
                        help='The client_id to use')

    parser.add_argument('-d', '--domain', action='store',
                        help='Used in conjunction with "--print" to filter on a domain of interest ')
    parser.add_argument('-p', '--plugin', action='store',
                        help='Used in conjunction with "--print" to filter on a plugin of interest ')
    parser.add_argument('-P', '--port', type=int, action='store', default=5588,
                        help='The port to use.') 
    parser.add_argument('-s', '--server', action='store', default='localhost',
                        help='The machine the server is running on. Defaults to %(default)s.')
    parser.add_argument('-t', '--timeout', type=int, action='store', default=10,
                        help='The timeout to use')  
    parser.add_argument('--debug', action='store_true',
                        help='Debug mode ')

    # this arguments do not require a plugin/domain and audio input
    parser.add_argument('--print', action='store_true',
                        help='Print plugin and domain information. If "-p/--plugin" and/or "-d/--domain" options are supplied, \
                            they will be used to filter the results. If --protected is supplied, the return will also include "protected" plugins ')
    parser.add_argument('--protected', action="store_true", help="Include 'protected' plugins when printing plugin and domain information")
    parser.add_argument('--status', action='store_true',
                        help='Get server status ')
    parser.add_argument('--heartbeat', action='store_true',
                        help='Continuously listen for and print out server heartbeat info ')
    
    parser.add_argument('--secure', action='store_true', 
                        help='Indicates a secure connection should be made.  Requires --certpath, --keypass, --keypath, and --cabundlepath to be set.')
    parser.add_argument('--certpath', action='store', 
                        help='Specifies the path of the certificate')
    parser.add_argument('--keypath', action='store', 
                        help='Specifies the path of the certificate key')
    parser.add_argument('--keypass', action='store', 
                        help='Specifies the certificate passphrase to unlock the encrypted certificate key')    
    parser.add_argument('--cabundlepath', action='store', 
                        help='Specifies the path of the certificate authority')

    args_bad = False
    args = parser.parse_args()

    # Simple logging config
    if args.debug:
        log_level = logging.DEBUG
    else:
        log_level = logging.INFO
        # log_level = logging.WARN
    logging.basicConfig(level=log_level)

    if not args.status and not args.print and not args.heartbeat:
        print(
            'No command has been given.  One of status, heartbeat, or print must be given or nothing will be done.')
        args_bad = True

    # checking for if tls is enabled and correctly set up
    secure_connect = False
    if args.secure:
        if (args.certpath is None or args.keypass is None or args.cabundlepath is None or args.keypath is None):
            args_bad = True
            print('--secure requires --certpath, --keypass, --keypath, and --cabundlepath')
        else:
            secure_connect = True

    if args_bad:
        print('Run the command with --help or -h to see all the command line options.')
        quit(1)

    client = olive_async.AsyncOliveClient(args.client_id, args.server, args.port, args.timeout)
    if not secure_connect:
        client.connect(monitor_status=True)
    else:
        client.secure_connect(certfile=args.certpath, keyfile=args.keypath, password=args.keypass, ca_bundle_path=args.cabundlepath, monitor_status=True)

    try:
        if args.status:
            status_response = client.get_status()
            if status_response.is_successful():
                print("OLIVE server status: {}".format(status_response.to_json()))

        if args.print:
            plugin_response = client.request_plugins(include_protected=args.protected)
            if plugin_response.is_successful():
                # print("Olive plugins: {}".format(json.dumps(plugin_response.to_json(), indent=1)))

                if args.plugin:
                    # filter results by plugin
                    json_output = plugin_response.to_json(indent=-1)['plugins']
                    matched = False
                    for pd in json_output:
                        if pd['id'] == args.plugin:
                            matched = True
                            if args.domain:
                                domains = pd['domain']
                                filtered_domains = []
                                for dom in domains:
                                    if dom['id'] == args.domain:
                                        filtered_domains.append(dom)
                                if not filtered_domains:
                                    print("Requested domain '{}' not found for plugin: '{}'".format(args.domain, args.plugin))
                                pd['domain'] = filtered_domains
                            print("Plugin: {}".format(json.dumps(pd, indent=1)))
                    if not matched:
                        print("Requested plugin '{}' not found".format(args.plugin))

                else:
                    print("Olive plugins: {}".format(plugin_response.to_json(indent=1)))

        if args.heartbeat:
            signal.signal(signal.SIGINT, signal.default_int_handler)    # instead of exiting immediately... cause the KeyboardInterrupt to be thrown so that the client can be disconnected properly below
            print("")
            print("Press CTRL-C to stop listening for OLIVE server heartbeats")
            print("")
            client.add_heartbeat_listener(heartbeat_notification)
            while True:
                time.sleep(.1)

    except Exception as e:
        print("olivepystatus failed with error: {}".format(e))
        print(traceback.format_exc())
    except KeyboardInterrupt:
        pass
    finally:
        if client:
            client.disconnect()

    print('Exiting...')
